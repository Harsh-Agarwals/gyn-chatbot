## Gen AI Pipeline

- Data Acquisition
- Data Preparation
- Feature Engineering
- Modelling
- Evaluation
- Deployment
- Monitoring